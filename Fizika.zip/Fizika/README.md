"# Fizika" 
